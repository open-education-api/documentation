<!-- markdownlint-disable MD041 -->
<!-- markdownlint-disable MD033 -->
* [OEAPI specification](specification/README.md#start)
* <li><a href="specification/specification.html">API reference</a></li>
* [Major changes](specification/major-changes.md#start)
* [Changelog](specification/CHANGELOG.md#start)
* [Versioning](specification/versioning.md#start)
* [Data model](specification/data-model.md#start)
* [Error codes](specification/errorcodes.md#start)
